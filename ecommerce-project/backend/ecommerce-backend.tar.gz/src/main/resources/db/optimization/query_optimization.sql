-- 查询优化：创建常用查询的视图
CREATE OR REPLACE VIEW `v_active_products` AS
SELECT
    p.id,
    p.name,
    p.price,
    p.stock,
    p.category,
    p.image_url,
    CASE
        WHEN p.stock > 10 THEN 'In Stock'
        WHEN p.stock BETWEEN 1 AND 10 THEN 'Low Stock'
        ELSE 'Out of Stock'
        END as availability
FROM `products` p
WHERE p.status = 'ACTIVE'
ORDER BY p.created_at DESC;

-- 创建存储过程：更新库存
DELIMITER $$
CREATE PROCEDURE `sp_update_product_stock`(
    IN p_product_id BIGINT,
    IN p_quantity_change INT
)
BEGIN
UPDATE `products`
SET
    stock = stock + p_quantity_change,
    status = CASE
                 WHEN (stock + p_quantity_change) <= 0 THEN 'OUT_OF_STOCK'
                 WHEN status = 'OUT_OF_STOCK' AND (stock + p_quantity_change) > 0 THEN 'ACTIVE'
                 ELSE status
        END,
    updated_at = CURRENT_TIMESTAMP
WHERE id = p_product_id;
END$$
DELIMITER ;

-- 创建函数：计算类别统计
DELIMITER $$
CREATE FUNCTION `fn_get_category_stats`(p_category VARCHAR(100))
    RETURNS VARCHAR(100)
    DETERMINISTIC
BEGIN
    DECLARE total_count INT;
    DECLARE avg_price DECIMAL(10,2);

SELECT COUNT(*), AVG(price)
INTO total_count, avg_price
FROM `products`
WHERE category = p_category AND status = 'ACTIVE';

RETURN CONCAT('Count: ', total_count, ', Avg Price: ¥', FORMAT(avg_price, 2));
END$$
DELIMITER ;